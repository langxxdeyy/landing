<?php

// Path folder tempat sitemap.php berada
$directoryPath = dirname(__FILE__);

// File daftar brand
$fileName = $directoryPath . '/brand.txt';

// Baca brand
$entries = file_exists($fileName)
    ? file($fileName, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES)
    : [];

// Base URL
$baseUrl = 'https://' . $_SERVER['HTTP_HOST'];

// Ambil path folder dari sitemap.php
$folderPath = dirname($_SERVER['SCRIPT_NAME']);

if ($folderPath === '/' || $folderPath === '.') {
    $folderPath = '';
}

$folderPath = rtrim($folderPath, '/');

// URL folder
$folderUrl = $baseUrl . $folderPath;

// Buat XML sitemap
$sitemap = new SimpleXMLElement(
    '<?xml version="1.0" encoding="UTF-8"?>' .
    '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>'
);

// Lastmod
$lastmod = gmdate('Y-m-d\TH:i:s+00:00');


/*
|--------------------------------------------------------------------------
| HOMEPAGE
|--------------------------------------------------------------------------
*/

$url = $sitemap->addChild('url');

$url->addChild(
    'loc',
    $baseUrl . '/'
);

$url->addChild(
    'lastmod',
    $lastmod
);

$url->addChild(
    'priority',
    '1.00'
);


/*
|--------------------------------------------------------------------------
| BRAND
|--------------------------------------------------------------------------
*/

foreach ($entries as $entry) {

    $brandName = trim($entry);

    if ($brandName === '') {
        continue;
    }

    // Lowercase
    $formattedEntry = strtolower($brandName);

    // Spasi menjadi -
    $formattedEntry = preg_replace(
        '/\s+/',
        '-',
        $formattedEntry
    );


    // URL:
    // https://domain.com/about/brand
    $url = $sitemap->addChild('url');

    $url->addChild(
        'loc',
        $folderUrl . '/' . rawurlencode($formattedEntry)
    );

    $url->addChild(
        'lastmod',
        $lastmod
    );

    $url->addChild(
        'priority',
        '1.00'
    );
}


/*
|--------------------------------------------------------------------------
| SIMPAN sitemap.xml
|--------------------------------------------------------------------------
*/

$sitemapFilePath = $directoryPath . '/sitemap.xml';

$sitemap->asXML($sitemapFilePath);

?>