<?php

/*
|--------------------------------------------------------------------------
| fungsi feedback404
|--------------------------------------------------------------------------
| Ditambah pengecekan: kalau WordPress tidak ada,
| jangan langsung blank. Keluarkan 404 polos.
*/

function feedback404()
{
    http_response_code(404);

    $wp = __DIR__ . '/wp-blog-header.php';

    if (file_exists($wp)) {
        define( 'WP_USE_THEMES', true );
        require $wp;
        exit();
    }

    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html>';
    echo '<html><head><meta charset="utf-8"><title>404</title></head>';
    echo '<body><h1>404 - Halaman tidak ditemukan</h1></body></html>';
    exit();
}


/*
|--------------------------------------------------------------------------
| 1. AMBIL ID DARI URL
|--------------------------------------------------------------------------
|
| Mendukung dua bentuk URL (prioritas: URL bersih /ID):
|
|  https://domain.com/badak178-ayamjp          -> ID dari path
|  https://domain.com/?ID=badak178-ayamjp      -> ID dari query (fallback)
|
*/

// Ambil ID dari URL path bersih
$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
$pathSegments = array_values(array_filter(explode('/', $requestPath), 'strlen'));
$lastSegment = $pathSegments ? strtolower($pathSegments[count($pathSegments) - 1]) : '';

// Segmen yang jelas BUKAN ID brand
$nonIdSegments = [
    'index.php', 'index.html', 'index.htm', 'index',
    'amp', 'amp.html', 'home', ''
];
if (in_array($lastSegment, $nonIdSegments, true)) {
    $lastSegment = '';
}

// Prioritas: ID dari path bersih -> fallback ke ?ID=
if ($lastSegment !== '' && preg_match('/^[a-z0-9-]+$/', $lastSegment)) {
    $targetID = $lastSegment;
} elseif (isset($_GET['ID']) && trim($_GET['ID']) !== '') {
    $targetID = strtolower(trim($_GET['ID']));
    $targetID = preg_replace('/[^a-z0-9-]/', '', $targetID);
} else {
    feedback404();
}

$targetID = strtolower(trim($targetID));


/*
|--------------------------------------------------------------------------
| Validasi ID
|--------------------------------------------------------------------------
*/

if ($targetID === '' || !preg_match('/^[a-z0-9-]+$/', $targetID)) {
    feedback404();
}


/*
|--------------------------------------------------------------------------
| 2. FILE CSV
|--------------------------------------------------------------------------
*/

$csvFile = __DIR__ . '/data.csv';

if (!file_exists($csvFile)) {
    http_response_code(500);
    exit('data.csv tidak ditemukan');
}

$handle = fopen($csvFile, 'r');

if (!$handle) {
    http_response_code(500);
    exit('Gagal membuka data.csv');
}


/*
|--------------------------------------------------------------------------
| 3. BACA HEADER CSV
|--------------------------------------------------------------------------
*/

$headers = fgetcsv($handle);

if (!$headers) {
    fclose($handle);
    feedback404();
}


/*
|--------------------------------------------------------------------------
| Hapus BOM UTF-8
|--------------------------------------------------------------------------
*/

$headers[0] = preg_replace(
    '/^\xEF\xBB\xBF/',
    '',
    $headers[0]
);


/*
|--------------------------------------------------------------------------
| Bersihkan header
|--------------------------------------------------------------------------
*/

foreach ($headers as $i => $header) {
    $headers[$i] = trim($header);
}


/*
|--------------------------------------------------------------------------
| 4. CARI ID DI CSV
|--------------------------------------------------------------------------
*/

$DATA = null;

while (($row = fgetcsv($handle)) !== false) {

    /*
     * Pastikan jumlah kolom sesuai header
     */

    if (count($row) < count($headers)) {
        $row = array_pad(
            $row,
            count($headers),
            ''
        );
    }


    /*
     * ID berada di kolom pertama
     */

    $csvID = strtolower(
        trim($row[0] ?? '')
    );

    $csvID = str_replace(
        ' ',
        '-',
        $csvID
    );


    /*
     * Cocokkan ID
     */

    if ($csvID !== $targetID) {
        continue;
    }


    /*
     * Simpan seluruh data
     */

    $DATA = [];

    foreach ($headers as $index => $header) {

        if ($header === '') {
            continue;
        }

        $DATA[$header] = $row[$index] ?? '';
    }

    break;
}

fclose($handle);


/*
|--------------------------------------------------------------------------
| 5. ID TIDAK DITEMUKAN
|--------------------------------------------------------------------------
*/

if ($DATA === null) {
    feedback404();
}


/*
|--------------------------------------------------------------------------
| 6. CANONICAL OTOMATIS
|--------------------------------------------------------------------------
|
| Contoh:
|
| https://domain.com/?ID=josbet51
|
| menjadi canonical:
|
| https://domain.com/josbet51
|
|--------------------------------------------------------------------------
*/

$protocol = (
    isset($_SERVER['HTTPS']) &&
    $_SERVER['HTTPS'] !== 'off'
)
    ? 'https'
    : 'http';

$canonical =
    $protocol .
    '://' .
    $_SERVER['HTTP_HOST'] .
    '/' .
    $targetID;


/*
|--------------------------------------------------------------------------
| 7. AMP URL OTOMATIS
|--------------------------------------------------------------------------
|
| Contoh:
|
| https://amp.d-cdn.org/poseye.org/?ID=josbet51
|
|--------------------------------------------------------------------------
*/

$ampURL =
    'https://digimarconaarhus.pages.dev/' .
    rawurlencode($targetID);


/*
|--------------------------------------------------------------------------
| 8. SPECIAL PLACEHOLDER
|--------------------------------------------------------------------------
|
| Semua ini BUKAN kolom CSV.
|
| namaseo.txt = brand-utama
|
|--------------------------------------------------------------------------
*/

$special = [

    /*
     * Canonical
     */
    '<canonical.txt>' => htmlspecialchars(
        $canonical,
        ENT_QUOTES,
        'UTF-8'
    ),


    /*
     * AMP
     */
    '<amp.txt>' => htmlspecialchars(
        $ampURL,
        ENT_QUOTES,
        'UTF-8'
    ),


    /*
     * Slug = ID
     */
    '<slug.txt>' => htmlspecialchars(
        $targetID,
        ENT_QUOTES,
        'UTF-8'
    ),


    /*
     * Nama SEO = brand-utama
     */
    '<namaseo.txt>' => htmlspecialchars(
        $DATA['brand-utama'] ?? $targetID,
        ENT_QUOTES,
        'UTF-8'
    ),

];


/*
|--------------------------------------------------------------------------
| 9. LOAD TEMPLATE
|--------------------------------------------------------------------------
*/

$templateFile = __DIR__ . '/template.html';

if (!file_exists($templateFile)) {
    http_response_code(500);
    exit('template.html tidak ditemukan');
}

$template = file_get_contents($templateFile);


/*
|--------------------------------------------------------------------------
| 10. REPLACE SPECIAL PLACEHOLDER
|--------------------------------------------------------------------------
*/

$template = str_replace(
    array_keys($special),
    array_values($special),
    $template
);


/*
|--------------------------------------------------------------------------
| 11. REPLACE PLACEHOLDER DARI CSV
|--------------------------------------------------------------------------
|
| Contoh:
|
| CSV:
| brand-utama = JOSBET51
|
| Template:
| <brand-utama.txt>
|
| Hasil:
| JOSBET51
|
|--------------------------------------------------------------------------
*/

foreach ($DATA as $columnName => $value) {

    /*
     * Field yang TIDAK berasal dari CSV
     */

    $blocked = [

        'ID',

        'canonical',
        'amp',
        'slug',
        'namaseo',

        'logo-web',
        'favicon',
        'gambar',

        'tombol-1',
        'tombol-2',

        'link-livechat',

        'link-1',
        'link-2',
        'link-3',
        'link-4',
        'link-5',
        'link-6',

        'warna-1',
        'warna-2',
        'warna-3'
    ];


    /*
     * Skip field yang diblokir
     */

    if (in_array($columnName, $blocked, true)) {
        continue;
    }


    /*
     * Buat placeholder .txt
     */

    $placeholder =
        '<' .
        $columnName .
        '.txt>';


    /*
     * Replacement
     */

    $template = str_replace(
        $placeholder,
        $value,
        $template
    );
}


/*
|--------------------------------------------------------------------------
| 12. OUTPUT
|--------------------------------------------------------------------------
*/

echo $template;

?>